from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.

class User(AbstractUser):
    usertype = models.CharField(max_length=30,null=True)

class Approve(models.Model):
    # aprv = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=30,null=False)
    email = models.EmailField(unique=True,null=False)
    phone = models.IntegerField(unique=True,null=False)
    age = models.IntegerField(null=False)
    gender = models.CharField(max_length=20,null=False)
    username = models.CharField(max_length=30,unique=True,null=False)
    password = models.CharField(max_length=30,null=False)
    

class Teacher(models.Model):
    tea = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=30,null=False)
    email = models.EmailField(unique=True,null=False)
    phone = models.IntegerField(unique=True,null=False)
    age = models.IntegerField(null=False)
    gender = models.CharField(max_length=20,null=False)
    department = models.CharField(max_length=50,null=False)
    password = models.CharField(max_length=30,null=False)
    

class Student(models.Model):
    stud = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=30,null=False)
    email = models.EmailField(unique=True,null=False)
    phone = models.IntegerField(unique=True,null=False)
    age = models.IntegerField(null=False)
    gender = models.CharField(max_length=20,null=False)
    password = models.CharField(max_length=30,null=False)
   