from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from app.models import User,Approve,Teacher,Student
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
# Create your views here.
def index(request):
    return render(request,"index.html")

def stud_reg(request):
    if request.method == 'POST':
        na = request.POST['name']
        em = request.POST['email']
        ph = request.POST['phone']
        ag = request.POST['age']
        gn = request.POST['gender']
        us = request.POST['username']
        pwd = request.POST['password']
        
        x = Approve.objects.create(name=na,email=em,phone=ph,age=ag,gender=gn,username=us,password=pwd)
        # n = User.objects.create_user(username=us,first_name=na,email=em,password=pwd,usertype='Student')
        
        x.save()
        return redirect(logins)
        
    else:
        return render(request,'stud_reg.html')
    
def logins(request):
    if request.method == 'POST':
        us = request.POST['username']
        pwd = request.POST['password']
        x = authenticate(request,username=us,password=pwd)
        if x is not None and x.is_superuser==1:
            return render(request,"admin_home.html")
        elif x is not None and x.usertype=='Student':
            login(request,x)
            request.session['st_id']=x.id
            return render(request,"stud_home.html",{"data":x})
    
        elif x is not None and x.usertype=='Teacher':
            login(request,x)
            request.session['t_id']=x.id
            return render(request,"tea_home.html",{"data":x})
        else:
            return HttpResponse("You are not registered. Please register to continue...")
    else:
        return render(request,"login.html")

def logouts(request):
    logout(request)
    return redirect(logins)
    

@login_required
def admin_home(request):
    return render(request,"admin_home.html")



def approve_student(request):
    x = Approve.objects.all()
    return render(request,"approve_stud.html",{'txt':x})




def reject_stud(request,id):
    # x = Approve.objects.get(id=id)
    # x.delete()
    # return HttpResponse("deleted")
    x = Approve.objects.get(id=id)
    x.delete()
    return redirect(approve_student)

def approve_stud(request,id):
    x = Approve.objects.get(id=id)
    na = x.name 
    em = x.email 
    ag = x.age
    gn = x.gender
    us = x.username
    ph = x.phone 
    psd = x.password
    
    n = User.objects.create_user(username=us,password=psd,usertype='Student')
    y = Student.objects.create(name=na,email=em,age=ag,gender=gn,phone=ph,password=psd,stud=n)
    y.save()
    x.delete()
    
   
    return redirect(approve_student)


def view_student(request):
    y = Student.objects.all()
    return render(request,"view_student.html",{'val':y})
        

def ad_st_edit(request,id):
    x = Student.objects.get(id=id)
    return render(request,"ad_st_edit.html",{'data':x})


def ad_upd_stud(request,id):
    if request.method == 'POST':
        na = request.POST['name']
        em = request.POST['email']
        ph = request.POST['phone']
        ag = request.POST['age']
        gn = request.POST['gender']
        # us = request.POST['username']
        # pwd = request.POST['password']
        # cpwd = request.POST['cpassword']

        old = Student.objects.get(id=id)
        old.name = na
        old.email = em
        old.phone = ph
        old.age = ag
        old.gender = gn
        # old.password = pwd
        old.save()
        User.objects.filter(id=id).update(first_name=na,email=em)
        return redirect(view_student)



def ad_st_dlt(request,id):
    User.objects.get(id=id).delete()
    x = Student.objects.get(id=id)
    x.delete()
    return redirect(view_student)

def add_teachers(request):
    if request.method == 'POST':
        na = request.POST['name']
        em = request.POST['email']
        ph = request.POST['phone']
        ag = request.POST['age']
        gn = request.POST['gender']
        us = request.POST['username']
        pwd = request.POST['password']
        dep = request.POST['department']
        cpwd = request.POST['cpassword']
        n = User.objects.create_user(username=us,first_name=na,email=em,password=pwd,usertype='Teacher')
        x = Teacher.objects.create(name=na,email=em,phone=ph,department=dep,age=ag,gender=gn,password=pwd,tea=n)
        if pwd==cpwd:
            x.save()
            return render(request,"admin_home.html")
        else:
            return HttpResponse("password must be equal")
    else:
        return render(request,'add_teacher.html')
    
def view_teacher(request):
    x = Teacher.objects.all()
    return render(request,"view_teacher.html",{'val':x})

def tea_delete(request,id):
    x = Teacher.objects.get(id=id)
    x.delete()
    return redirect(view_teacher)

def tea_edit(request,id):
    x = Teacher.objects.get(id=id)
    return render(request,"tea_edit.html",{'data':x})

def ad_tea_update(request,id):
    if request.method == 'POST':
        na = request.POST['name']
        em = request.POST['email']
        ph = request.POST['phone']
        ag = request.POST['age']
        gn = request.POST['gender']
        dep = request.POST['department']
        # us = request.POST['username']
        # pwd = request.POST['password']
        # cpwd = request.POST['cpassword']

        old = Teacher.objects.get(id=id)
        old.name = na
        old.email = em
        old.phone = ph
        old.age = ag
        old.department = dep
        old.gender = gn
        old.save()
        User.objects.filter(id=id).update(first_name=na,email=em)
        return redirect(view_teacher)


def teacher_edit_profile(request):
    x = request.session['t_id']
    y = User.objects.get(id=x)
    z = Teacher.objects.get(tea=x)
    return render(request,"teacher_edit_profile.html",{'data':y,'text':z})

def tea_upd_profile(request):
    if request.method == 'POST':
        
        na = request.POST['name']
        ph = request.POST['phone']
        em = request.POST['email']
        ag = request.POST['age']
        gn = request.POST['gender']
        dep = request.POST['department']
        us = request.POST['username']
        pwd = request.POST['password']
        cpwd = request.POST['cpassword']

        x = request.session['t_id']
        old = User.objects.get(id=x)
        old_data = Teacher.objects.get(tea=x)
        old.first_name = na
        old.email = em
        old.username = us
        old.password = pwd
        
        old_data.name = na
        old_data.email = em
        old_data.phone = ph
        old_data.age = ag
        old_data.gender = gn
        old_data.department = dep
        old_data.password = pwd
        if pwd == cpwd:
            old.save()
            old_data.save()
        else:
            return HttpResponse("Passwords doesn't match...try again!")
        return render(request,"tea_home.html",{'data':old})

@login_required  
def tea_home(request):
    return render(request,"tea_home.html")

def tea_view_student(request):
    x = Student.objects.all()
    return render(request,"tea_view_student.html",{'val':x})





def stud_edit_profile(request):
    x = request.session['st_id']
    y = User.objects.get(id=x)
    z = Student.objects.get(stud=x)
    return render(request,"stud_edit_profile.html",{'val':y,'txt':z})

def stud_upd_prof(request):
    if request.method == 'POST':
        na = request.POST['name']
        em = request.POST['email']
        ag = request.POST['age']
        gn = request.POST['gender']
        ph = request.POST['phone']
        us = request.POST['username']
        pwd = request.POST['password']
        cpwd = request.POST['cpassword']
        x = request.session['st_id']
        old = User.objects.get(id=x)
        old_data = Student.objects.get(stud=x)
        old.first_name = na
        old.email = em
        old.username = us
        old.password = pwd

        
        old_data.name = na
        old_data.email = em
        old_data.age = ag
        old_data.gender = gn
        old_data.phone = ph
        old_data.password = pwd
        if pwd == cpwd:
            old.save()
            old_data.save()
        else:
            return HttpResponse("Passwords doesn't match...try again!")
        return render(request,"stud_home.html",{'data':old})
        

def stud_view_tea(request):
    x = Teacher.objects.all()
    return render(request,"stud_view_tea.html",{'data':x})

@login_required
def stud_home(request):
    return render(request,"stud_home.html")